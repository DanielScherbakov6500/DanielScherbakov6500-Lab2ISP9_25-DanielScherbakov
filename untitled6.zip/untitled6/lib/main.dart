import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Comic App',
      home: LoginPage(),
    );
  }
}

class LoginPage extends StatelessWidget {
  final TextEditingController _usernameController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Login')),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              TextField(
                controller: _usernameController,
                decoration: InputDecoration(hintText: 'Username'),
              ),
              SizedBox(height: 20),
              TextField(
                controller: _passwordController,
                decoration: InputDecoration(hintText: 'Password'),
                obscureText: true,
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context) => ComicsPage()));
                },
                child: Text('Login'),
              ),
              SizedBox(height: 10),
              TextButton(
                onPressed: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context) => RegisterPage()));
                },
                child: Text('Register'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class RegisterPage extends StatelessWidget {
  final TextEditingController _usernameController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Register')),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              TextField(
                controller: _usernameController,
                decoration: InputDecoration(hintText: 'Username'),
              ),
              SizedBox(height: 20),
              TextField(
                controller: _passwordController,
                decoration: InputDecoration(hintText: 'Password'),
                obscureText: true,
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context) => ComicsPage()));
                },
                child: Text('Register'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class ComicsPage extends StatelessWidget {
  final List<Map<String, String>> popularComicsData = [
    {
      'imagePath': 'https://d1466nnw0ex81e.cloudfront.net/n_iv/600/887571.jpg',
      'description': 'Флэш обладает способностью развивать скорость, превышающую скорость света, и использовать сверхчеловеческие рефлексы, что нарушает некоторые законы физики. Здесь представлен один из комиксов DC Флэш'
          'Цена 12 : долларов',
    },
    {
      'imagePath': 'https://i.pinimg.com/originals/ff/a8/91/ffa8916c4887b1eb0069e8cc3a9bde8c.jpg',
      'description': 'Бэтмен - супергерой-защитник Готэм-Сити, измученный, задумчивый линчеватель в костюме летучей мыши, который борется со злом и вселяет страх в сердца преступников повсюду. В своей публичной ипостаси он Брюс Уэйн, промышленник-миллиардер и печально известный плейбой. Хотя у него нет сверхчеловеческих способностей, он один из самых умных людей в мире и величайших бойцов. Здесь представлен один из комиксов DC Бэтмен'
          'Цена 13 : долларов',
    },
    {
      'imagePath': 'https://i.pinimg.com/736x/e1/32/c7/e132c7fa631ff414bcc39953164d2394.jpg',
      'description': 'Также известен как «Человек из стали» — один из сильнейших супергероев во вселенной DC. Его способности включают в себя невероятную суперсилу, суперскорость, неуязвимость, ледяное дыхание, полет и тепловое зрение. Настоящее имя — Кал-Эл. Родился Кал-Эл на умирающей планете Криптон. Его родители Джор-Эл и Лара отправили его в ракете к планете Земля, где он будет последним выжившим представителем своего вида. Здесь представлен один из старых комиксов DC Супермена'
          'Цена : 10 долларов',
    },
  ];

  final List<Map<String, String>> allComicsData = [
    {
      'imagePath': 'https://cdn.img-gorod.ru/nomenclature/27/091/2709137.jpg',
      'description': 'Чудо-женщина — принцесса амазонок (основана на греческой мифологии), у себя на родине известна как Диана (англ. Diana). Диана регулярно появлялась в комиксах, начиная с 1941 года, за исключением небольшого периода после Кризиса на Бесконечных Землях в 1986 году, стала одним из самых популярных персонажей Золотого века комиксов и была одной из пяти, истории о которых не прекратили выпускаться после Второй мировой войны. Одна из немногих популярных женщин в комиксах. Диана серьёзная, опытная героиня, но в душе добрая, дружелюбная и милосердная, готовая оказывать помощь другим. Здесь представлен один из старых комиксов DC Чудо Женщина'
          'Цена : 15 долларов',
    },
    {
      'imagePath': 'https://i.pinimg.com/originals/b2/8c/18/b28c189c9b932a93046e466c28d005a6.jpg',
      'description': 'Джокер (Тристер/Шут) - архетип в мифологии, комический дублёр культурного героя, который совершает противоправные действия или не подчиняющееся общим правилам поведения. Основное желание этого персонажа - жить в настоящем, извлекая из этого максимум удовольствия. Цель Джокера - зажигательно провести время и повеселить окружающий мир. Его страх - быть скучным, остаться не увиденным, обыденным. Здесь представлен один из старых комиксов DC Джокер'
          'Цена : 8 долларов',
    },
    {
      'imagePath': 'https://i.pinimg.com/originals/48/96/e2/4896e23549269f648d1bed4db1809144.jpg',
      'description': 'Виктор «Вик» Стоун — сын Сайласа Стоуна и Элинор Стоун, ученых лаборатории «S.T.A.R.», которые ставили над ним эксперимент по повышению интеллекта. Возмужав, Вик осуждает проводимые над ним опыты. Обладая высоким IQ, он тем не менее интересовался больше спортом, нежели наукой. Его жизнь кардинально изменилась, когда, он в очередной раз явился в лабораторию «S.T.A.R.», чтобы встретиться с родителями. Те проводили межпространственный эксперимент, в результате которого в лабораторию проникло протоплазматическое существо. Оно убило Элинор и тяжело ранило Вика. Сайласу Стоуну удалось вернуть существо обратно в его измерение, и надеясь спасти жизнь сыну, учёный применил непроверенную технологию по кибернетическому усовершенствованию тела Виктора. Попытка оказалась успешной и Виктор становится Киборгом. Здесь представлен один из комиксов DC Киборг'
          'Цена : 14 долларов',
    },
  ];
  final List<String> users = ["Чудо Женщина", "Джокер", "Киборг"];
  final List<IconData> icons = [Icons.book_outlined, Icons.book_outlined, Icons.book_outlined];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Комиксы')),
      body: Column(
        children: <Widget>[
          SizedBox(
            height: 200,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: popularComicsData.length,
              itemBuilder: (context, index) {
                return InkWell(
                  onTap: () {
                    Navigator.push(context, MaterialPageRoute(builder: (context) => ComicDetailPage(imagePath: popularComicsData[index]['imagePath']!, description: popularComicsData[index]['description']!)));
                  },
                  child: Container(
                    margin: EdgeInsets.all(4.0),
                    width: 130,
                    child: Image.network(popularComicsData[index]['imagePath']!, fit: BoxFit.cover),
                  ),
                );
              },
            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: allComicsData.length,
              itemBuilder: (context, index) {
                return ListTile(
                    title: Text(users[index]),
                  leading: Icon(icons[index]),
                    onTap: () {
                    Navigator.push(context, MaterialPageRoute(builder: (context) => ComicDetailPage(imagePath: allComicsData[index]['imagePath']!, description: allComicsData[index]['description']!)));
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class ComicDetailPage extends StatelessWidget {
  final String imagePath;
  final String description;

  ComicDetailPage({required this.imagePath, required this.description});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Подробности комикса')),
      body: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.network(imagePath, width: 200),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text(
                description,
                textAlign: TextAlign.center,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
// class ComicsPage extends StatelessWidget {
//   final List<Map<String, String>> popularComicsData = [
//     // ваши данные popularComicsData
//   ];
//
//   final List<Map<String, String>> allComicsData = [
//     // ваши данные allComicsData
//   ];
//
//   final List<Map<String, dynamic>> salesData = [
//     {
//       'product': 'Flash Comic Book',
//       'price': 25.99,
//       'imagePath': popularComicsData[0]['imagePath'], // пример использования изображения из popularComicsData
//       'description': 'Flash Comic Book Description',
//     },
//     {
//       'product': 'Batman Graphic Novel',
//       'price': 19.99,
//       'imagePath': popularComicsData[1]['imagePath'], // пример использования изображения из popularComicsData
//       'description': 'Batman Graphic Novel Description',
//     },
//     {
//       'product': 'Superman Collector\'s Edition',
//       'price': 29.99,
//       'imagePath': allComicsData[2]['imagePath'], // пример использования изображения из allComicsData
//       'description': 'Superman Collector\'s Edition Description',
//     },
//     // Добавьте другие товары по аналогии
//   ];